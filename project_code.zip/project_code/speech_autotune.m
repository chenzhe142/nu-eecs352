%[y,fs]=audioread('sdf.mp3');
function y_mix=speech_autotune(ee,m_drum,m_tempo,m_beats)
y=ee;
fs=44100;
if size(y,1)>size(y,2)
    y=y(:,1)';
end
[frq_path, autoCorr_path, time, amp] = praat_pd(y,fs,0);

%tempo estimation
[onset_fn, osr, ~] = beat_onset(y,fs);
tempo = beat_tempo(onset_fn, osr, 0);

%speech onsets dectection
onset=find(amp>0.02);
onset=onset(1);%find where speech start
t=length(time);
r=zeros(1,t);
for n=onset+1:t-4
    if amp(n)>0.0002
    if amp(n)<amp(n-1) && amp(n)<amp(n-2)
        if amp(n)<amp(n+1) && amp(n)<amp(n+2)
            if amp(n)<amp(n-5) && amp(n)<amp(n+5)
                r(n)=1;
            end;end; end;end;end
r=find(r~=0);



mean_frq=mean(frq_path(find(frq_path~=0)));
step=floor(length(y)/t);
y1=[];
base=round(mean_frq/131)*131;
z=zeros(1,step);
rlen=length(r);

ff=zeros(1,rlen);
for n=1:length(r)-1 %build corresponding tuned frequency vector
    f_m=frq_path(r(n):r(n+1));
    f_mean=mean(f_m(find(f_m~=0)));
    if f_mean>0        
        x_f = 12*log2(f_mean/base);
        xf=x_f;
        if xf<-0.5
            x_f=x_f+12;
        elseif xf>11.5
            x_f=x_f-12;
        end;
        if (((-0.5<=x_f)&&(x_f<1)) || (x_f>11.5)) 
            x_ff=0;
        elseif 1<=x_f && x_f<3 
            x_ff=2;
        elseif 3<=x_f && x_f<4.5
            x_ff=4;
        elseif 4.5<=x_f&&x_f<6
            x_ff=5;
        elseif 6<=x_f&&x_f<8
            x_ff=7;
        elseif 8<=x_f&&x_f<10
            x_ff=9;
        else x_ff=11;
        end;
        if xf<-0.5 
            x_ff=x_ff-12;
        elseif xf>11.5 
            x_ff=x_ff+12;
        end;
        x_ff=x_ff+2;%life pitch
        ff(n)=2^((x_ff)/12)*base;
    else
        ff(n)=0;
    end
end
ff=[ff 0];%avoid conflict
ff=[mean_frq ff];
r=[r (r(length(r))+200)];
a=2;

% ff=[1 1 1 1 3 3 1 1 1 1 7 5 3 1 3 3 3 3 5 5 5 5 2 2 2 2 1 3 5 5 5 3 1];
% ff=ff+1;
% ff=2.^(ff/12)*mean_frq;

for n=1:t-1
    Start = 1+(n-1)*step;%the start and end positions for each step
    End = n*step; 
    xx = y(Start:End);
    if n>=r(a+1)
           a=a+1;%read next note
    end;
        if frq_path(n)==0 
            y1=[y1 xx];
        else
            if round(ff(a))==0 
                if round(ff(a-1))~=0
                    wav=resample(xx,round(frq_path(n)),round(ff(a-1)));
                else 
                    wav=xx;
                end
            else
                wav = resample(xx,round(frq_path(n)),round(ff(a))); 
            end;           
            y1=[y1 wav];
        end
 end

if m_tempo==0
    y_mix=y1;
else
    [frq_aa,bb,cc,amp_dd] = praat_pd(y1,fs,0);

    r_frag=[];%get index of speech segment
    y1onset=find(frq_aa~=0);
    y1_onset=y1onset(1);
    for n=y1_onset:length(frq_aa)-4
        if frq_aa(n)>0&&frq_aa(n-1)==0
            r_frag=[r_frag n];
        end
    end

    %adjust r_frag to avoid too short sound fragment

    % new_f=r_frag(1);
    % for n=2:length(r_frag)
    %     if (r_frag(n)-r_frag(n-1))>ceil(60*44100/(m_tempo*step*2))%if larger than half beat time
    %         new_f=[new_f r_frag(n)];
    %     end
    % end
    % r_frag=new_f;

    %adjust r_frag
    m_a=1;
    %mm_beats=m_beats(1:2:end);
    new_f=r_frag(1);
    for m=1:length(r_frag)-1
    %m is recent place, m_a-m is length
        if (r_frag(m)-r_frag(m_a))>ceil(2*60*44100/(m_tempo*step))
            new_f=[new_f r_frag(m)];
            m_a=m;
        end
    end
    r_frag=new_f;
    y_mix=m_drum*0.35;%reduce the amplitude of drumset
    n=1;

    for m=1:length(r_frag)-1
        start1=floor(m_beats(n)*44100);% in time
        start2=r_frag(m)*step; % in frq index
        end2=r_frag(m+1)*step-1;
        xg=y1(start2:end2);
        y_mix(start1:start1+length(xg)-1)=y_mix(start1:start1+length(xg)-1)+xg; 
        nn= ceil(length(xg)/(60*44100/m_tempo));
        n=n+nn;
    end

    start1=floor(m_beats(n)*44100);
    start2=r_frag(end);%add last fragment
    x_g=y1(start2:start2+round(2*60*44100/m_tempo));
    y_mix(floor(start1:start1+length(x_g)-1))=y_mix(start1:start1+length(x_g)-1)+x_g;
end
%y_mix1=PV(y_mix,fs,242,200);
