%wavfile='monster.mp3';
function y1=tuning(ee,m_vector,fs)
if char(ee)
    [x,fs] = audioread(ee);
else x=ee;
end
fs=44100;
if size(x,1)> size(x,2)
    x=x(:,1)';
end;
y=x;
[frq_path, autoCorr_path, time, amp] = praat_pd(y,fs,0);
tlen=size(time,1);
step=floor(size(y,2)/tlen);
onset_s=find(frq_path~=0);%find onset of the sound
onset_a=onset_s(1)*step/fs;
[onset_fn, osr, sgram, tt, ff] = beat_onset(y,fs);
mean_frq=mean(frq_path(find(frq_path~=0)));%find average sound frequency

tempo = beat_tempo(onset_fn, osr, 0);
if tempo<100
    tempo=tempo*2;
end;
beats = beat_simple(onset_fn, osr, tempo);

mm_vector=mean_frq*m_vector;
if onset_a>beats(1) %make beats start from onset
    for aa=1:10
        if onset_a-0.2>beats(1)
            beats=beats(2:end);
        else break;
        end;end;
else
    for aa=1:10
        if onset_a<beats(1)-0.2
            beats=[abs(beats(1)-60/tempo) beats];
        else break;
        end;end;
end;
beats=[beats 20];%add 20 as the maxmium time.
a=1;
z=zeros(1,step);
y1=[];
    for n = 1:tlen-1 %reconstruct signals
        Start = 1+(n-1)*step;%the start and end positions for each step
        End = n*step; 
        xx = y(Start:End);
        if frq_path(n)==0 
            y1=[y1 xx];
        else        
            if (n*step/fs)>beats(a+1)
                a=a+1;%read next note
            end;
            ff=frq_path(n);
            wav = resample(xx,round(frq_path(n)),round(mm_vector(a)));
            y1=[y1 wav];
        end
    end
y2=tempoadjust(y1,fs,mean_frq);
%soundsc(y1,fs);