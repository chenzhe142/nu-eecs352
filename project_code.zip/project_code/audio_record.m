recObj = audiorecorder(44100,16,1);
disp('Start speaking.')
recordblocking(recObj, 7);
disp('End of Recording.');

% Play back the recording.
play(recObj);

% Store data in double-precision array.
ee = getaudiodata(recObj);
%audiowrite('vioce_record1.mp3',ee,fs)
% Plot the waveform.
%plot(myRecording);