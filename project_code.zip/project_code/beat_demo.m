% First, load an example sound file
%wavfilename = 'las.wav';
%[d,sr] = audioread('terry.wav');
%function beat_demo(ee,sr)
d=m_drum;
sr=44100;
if size(d,2)== 2
    d=d(:,1)';
end;
% d=PV(d,sr,121,242);
% d=d';
%d=(1:130000);
[onset_fn, osr, sgram, tt, ff] = beat_onset(d,sr);

subplot(211)
imagesc(tt, ff, sgram); axis xy
subplot(212)
plot(tt(1:end-1), onset_fn);
linkaxes([subplot(211), subplot(212)], 'x');

linkaxes([subplot(211), subplot(212)], 'off');
subplot(211)
display = 1;
tempo = beat_tempo(onset_fn, osr, display);
if tempo<160;
    tempo=tempo*2;
end;
% Now we can run the dynamic programming beat tracker
beats = beat_simple(onset_fn, osr, tempo);

% We have some helper functions: one to plot the beat times on top
% of the Mel spectrogram (which we saved from beat_onset)
subplot(212)
beat_plot(beats, '-r', tt, ff, sgram);
%[frq_path, autoCorr_path, time, amp] = praat_pd(d,sr,1);
% And we can listen to the result; the system-found beats are
% marked by little tone bursts superimposed on the
% original:
 beat_play(beats, d, sr);
% 
% % We can go straight from soundfile to beats with beat_track, which
% % just provides a wrapper around the steps above:
% beats = beat_track(wavfilename);
% 
