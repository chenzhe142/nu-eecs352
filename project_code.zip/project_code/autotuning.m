%[y,fs]=audioread('sdf.mp3');
function y1=autotuning(ee,fs,key)
y=ee;
fs=44100;
if size(y,1)>size(y,2)
    y=y(:,1)';
end;
[frq_path, autoCorr_path, time, amp] = praat_pd(y,fs,0);
t=length(time);
mean_frq=mean(frq_path(find(frq_path~=0)));
step=floor(length(y)/t);
correct=zeros(1,t);
y1=[];
base=round(mean_frq/131)*131;
for n=1:t
    Start = 1+(n-1)*step;%the start and end positions for each step
    End = n*step; 
    xx = y(Start:End);
    zero_frq=mean_frq*(2^(1/3));
        if frq_path(n)==0 
            %if frequency is zero, append zeros to output
            y1=[y1 xx];
        else
            x = round(12*log2(frq_path(n)/base));
            ab=2^(x/12)*base;
            
            x_f = 12*log2(frq_path(n)/base);%tune to C major
            xf=x_f;
            if xf<-0.5
                x_f=x_f+12;
            elseif xf>11.5
                x_f=x_f-12;
            end;
            if (((-0.5<=x_f)&&(x_f<1)) || (x_f>11.5)) 
                x_ff=0;
            elseif 1<=x_f && x_f<3 
                x_ff=2;
            elseif 3<=x_f && x_f<4.5
                x_ff=4;
            elseif 4.5<=x_f&&x_f<6
                x_ff=5;
            elseif 6<=x_f&&x_f<8
                x_ff=7;
            elseif 8<=x_f&&x_f<10
                x_ff=9;
            else x_ff=11;
            end;
            if xf<-0.5 
                x_ff=x_ff-12;
            elseif xf>11.5 
                x_ff=x_ff+12;
            end;
            x_ff=x_ff+key;%keys is the number of half steps to shift 
            ab=2^((x_ff)/12)*base;               
            ff=frq_path(n);            
            %resample one step of signals
            wav = resample(xx,round(ff),round(ab));
            %append one step of resampled sound together;
            y1= [y1 wav];
        end
end
%[frq_aa,~] = praat_pd(y1,fs,0); %if add phase vocoder, the result doesn't
%sounds good
%mean_frq_aa=mean(frq_aa(find(frq_aa~=0)));
%y2=pvoc(y1',mean_frq/mean_frq_aa);
%y2=real(y2)';
% if mean_frq>242
%     y2=PV(y1,fs,mean_frq_aa/2,mean_frq/2);
%  else
%      y2=PV(y1,fs,mean_frq,mean_frq_aa);
%  end
%[aa, bb, cc, dd] = praat_pd(y,fs,1);
%sound(y1,fs)
