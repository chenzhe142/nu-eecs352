%soundfile='mary_melody.mp3';
function m_vector=extract1(mm,a)
if char(mm)
    [d,sr] = audioread(mm);
else d=mm;
    sr=a;
end
%d=PV(d,sr,121,242);
if size(d,1)>size(d,2)
    d=d';
end
d=d(1,:);
[frq_path, autoCorr_path, time, amp] = praat_pd(d,sr,0);
if mean(amp)<0.3
    ratio=0.2/mean(amp);
    d=10.*d;
end

[onset_fn, osr, sgram, tt, ff] = beat_onset(d,sr);

tempo = beat_tempo(onset_fn, osr, 0);
if tempo<155;
    tempo=tempo*2;
end;
beats = beat_simple(onset_fn, osr, tempo);


step=floor(length(d)/length(time));
onset_s=find(frq_path~=0);
onset_a=onset_s(1)*step/sr;

if onset_a>beats(1) %make beats fits to onset
    for aa=1:10
        if onset_a-0.2>beats(1)
            beats=beats(2:end);
        else break;
        end;end;
else
    for aa=1:10
        if onset_a<beats(1)-0.2
            beats=[abs(beats(1)-60/tempo) beats];
        else break;
        end;end;
end;

m_vector=size(1,length(beats));
for bb=1:length(beats)
    Start=floor(beats(bb)*sr/step)+1;
    End=floor((beats(bb)+60/tempo)*sr/step);
    
    if End>length(frq_path)
        loc=Start-1+find(frq_path(Start:end)>100);
        m_vector(bb)=mean(frq_path(loc));
    else
        loc=Start-1+find(frq_path(Start:End)>100);
        m_vector(bb)=mean(frq_path(loc));
    end
end;
%note=16.35*2^(floor(log2(mean(m_vector))/2));
m_vector=m_vector/min(m_vector);
m_vector=[m_vector(1:end-1) 1 1 1 1 1];