function varargout = GUI_2(varargin)
% GUI_2 MATLAB code for GUI_2.fig
%      GUI_2, by itself, creates a new GUI_2 or raises the existing
%      singleton*.
%
%      H = GUI_2 returns the handle to a new GUI_2 or the handle to
%      the existing singleton*.
%
%      GUI_2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_2.M with the given input arguments.
%
%      GUI_2('Property','Value',...) creates a new GUI_2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUI_2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUI_2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUI_2

% Last Modified by GUIDE v2.5 20-Mar-2015 14:38:09

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUI_2_OpeningFcn, ...
                   'gui_OutputFcn',  @GUI_2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

end
% --- Executes just before GUI_2 is made visible.
function GUI_2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI_2 (see VARARGIN)

% Choose default command line output for GUI_2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

G=imread('logo.png');
axes(handles.axes4);
imshow(G);

x=importdata('4.jpg');
set(handles.help_button,'CDATA',x);

% UIWAIT makes GUI_2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);
end

% --- Outputs from this function are returned to the command line.
function varargout = GUI_2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

end
% --- Executes on button press in load_button.
function load_button_Callback(hObject, eventdata, handles)
% hObject    handle to load_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global x
global fs
global m_v
h = guidata(gcbo);   
[filename,filepath] = uigetfile( ...                                        % Open file dialog box in the current directory
    {'*.wav;*.mp3', 'mp3 files (*.mp3)'; ...
    '*.*',  'All Files (*.*)'}, ...
    'Select a mp3 file');

[~,filename,fileext] = fileparts(filename);  
file = fullfile(filepath,[filename,fileext]); 
[x,fs] = audioread(file);
L = length(x);
axes(handles.plot_refer)
plot((1:L)/fs,x); 
set(handles.plot_refer, ...
    'XGrid','on',...
    'YGrid','off',...
    'XLim',[1,L]/fs, ...
    'YLim',[-1,1], ...
    'YTickLabel',[])
title(filename,'Interpreter','none')                                        % No interpreter to avoid underscore = subscript
xlabel('time (s)')

m_v=extract1(x,fs);
m_v=[m_v m_v m_v];

end

% --- Executes on button press in play_button1.
function play_button1_Callback(hObject, eventdata, handles)
% hObject    handle to play_button1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global x
global fs
h = guidata(gcbo);
if hObject
    soundsc(x,fs);
end

end

% --- Executes on button press in play_button2.
function play_button2_Callback(hObject, eventdata, handles)
% hObject    handle to play_button2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global input_speech
global fs
if hObject
    soundsc(input_speech,fs);
end
end

% --- Executes on button press in record_button.
function record_button_Callback(hObject, eventdata, handles)
% hObject    handle to record_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global input_speech
global fs
fs=44100;
recObj = audiorecorder(fs,16,1);
disp('Start speaking.')
recordblocking(recObj, 7);
disp('End of Recording.');

input_speech = getaudiodata(recObj);
L = length(input_speech);
axes(handles.plot_input)
plot((1:L)/fs,input_speech); 
set(handles.plot_input, ...
    'XGrid','on',...
    'YGrid','off',...
    'XLim',[1,L]/fs, ...
    'YLim',[-1,1], ...
    'YTickLabel',[])
title('Input','Interpreter','none')                                        % No interpreter to avoid underscore = subscript
xlabel('time (s)')

% Store data in double-precision array.
input_speech = getaudiodata(recObj);
soundsc(input_speech,fs)
end

% --- Executes on button press in melody_record.
function melody_record_Callback(hObject, eventdata, handles)
% hObject    handle to melody_record (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global m_v
global fs
global x
fs=44100;
recObj = audiorecorder(fs,16,1);
disp('Start speaking.')
recordblocking(recObj, 7);
disp('End of Recording.');

input_in = getaudiodata(recObj);
input=autotuning(input_in,fs,0);%correct input key
L = length(input);
axes(handles.plot_refer)
plot((1:L)/fs,input); 
set(handles.plot_input, ...
    'XGrid','on',...
    'YGrid','off',...
    'XLim',[1,L]/fs, ...
    'YLim',[-1,1], ...
    'YTickLabel',[])
title('Input','Interpreter','none')                                        % No interpreter to avoid underscore = subscript
xlabel('time (s)')

soundsc(input,fs)
x=input;
m_v=extract1(input,fs);
if m_v<20
    m_v=[m_v m_v];
end
end



% --- Executes on button press in speech_button.
function speech_button_Callback(hObject, eventdata, handles)
% hObject    handle to speech_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global x
global input_speech
global fs
global output_speech
global m_v
if hObject
    m_v=[m_v m_v m_v];
output_speech=tuning(input_speech,m_v,fs);

L = length(output_speech);
axes(handles.plot_output)
plot((1:L)/fs,output_speech); 
%cla(handles.plot_output,'reset')
set(handles.plot_output, ...
    'XGrid','on',...
    'YGrid','off',...
    'XLim',[1,L]/fs, ...
    'YLim',[-1,1], ...
   'YTickLabel',[])
title('Output','Interpreter','none')                                        % No interpreter to avoid underscore = subscript
xlabel('time (s)')
soundsc(output_speech,fs);
end
end

% --- Executes on button press in play_button3.
function play_button3_Callback(hObject, eventdata, handles)
% hObject    handle to play_button3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global output_speech
global fs
if hObject
    soundsc(output_speech,fs);
end
end

% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
end

% --- Executes during object creation, after setting all properties.
% function popupmenu1_CreateFcn(hObject, eventdata, handles)
% % hObject    handle to popupmenu1 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    empty - handles not created until after all CreateFcns called
% 
% % Hint: popupmenu controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
% end


% --- Executes on button press in Rap_button.
function Rap_button_Callback(hObject, eventdata, handles)
% hObject    handle to Rap_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global input_speech
global fs
global output_speech
Val=get(handles.popupmenu1,'Value');
switch(Val)
    case 1%'None'%
        m_tempo=0;
        m_drum=0;
        m_beats=0;
    case 2%'drumset1'%2
        load drumset1
    case 3%'drumset2'%3
        load drumset2
    case 4%'drumset3'%4
        load drumset3

end
        
output_speech=speech_autotune(input_speech,m_drum,m_tempo,m_beats);

L = length(output_speech);
axes(handles.plot_output)
plot((1:L)/fs,output_speech); 
%cla(handles.plot_output,'reset')
set(handles.plot_output, ...
    'XGrid','on',...
    'YGrid','off',...
    'XLim',[1,L]/fs, ...
    'YLim',[-1,1], ...
   'YTickLabel',[])
title('Output','Interpreter','none')                                        % No interpreter to avoid underscore = subscript
xlabel('time (s)')
soundsc(output_speech,fs);
end

% --- Executes on button press in Autotune_button.
function Autotune_button_Callback(hObject, eventdata, handles)
% hObject    handle to Autotune_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global input_speech
global fs
global output_speech
output_speech=autotuning(input_speech,fs,2);
L = length(output_speech);
axes(handles.plot_output)
plot((1:L)/fs,output_speech); 
%cla(handles.plot_output,'reset')
set(handles.plot_output, ...
    'XGrid','on',...
    'YGrid','off',...
    'XLim',[1,L]/fs, ...
    'YLim',[-1,1], ...
   'YTickLabel',[])
title('Output','Interpreter','none')                                        % No interpreter to avoid underscore = subscript
xlabel('time (s)')
soundsc(output_speech,fs);
end


% --- Executes on button press in help_button.
function help_button_Callback(hObject, eventdata, handles)
% hObject    handle to help_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% [i,~,a] = imread(fullfile(matlabroot,'toolbox','matlab','icons','tool_pointer.png'),'PNG'); % Use the pointer icon from MATLAB (i is the [16x16x3] 16-bit PNG image and a is the [16x16] AND mask for the transparency)
% i = im2double(i);                                                           % Convert the image to double precision, rescaling the data between 0 and 1
% a = im2double(a);                                                           % Convert the mask to double precision (0 = transparent pixels, 1 = non-transparent pixels)
% a(a==0) = NaN;                                                              % Convert 0 to NaN (= transparency for pushbutton's cdata)
% i = i.*repmat(a,[1,1,3]); 
% imshow(i)
if hObject
    open('help1.fig')
end
end
