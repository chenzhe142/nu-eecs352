function [ yout ] = tempoadjust( y1,fs,f0 )
%This is for adjusting the tempo after resampling melodies
%Input: y1 is the audio file; fs is sample rate; f0 is the mean frequency
%of that melody
%Output: yout is the output audio file
j=1; l=1;
yout=0;
[frq_path,~,time]= praat_pd(y1,fs);
for i=2:length(frq_path)
    if frq_path(i)~=0
        if abs(frq_path(i)-frq_path(i-1))>5
           s(j)=i;
           j=j+1;
        end
    end
end

step=length(y1)/length(time);
snew=round(s*step);
for i=1:length(snew)
fmean=f0;
if i==length(snew)
    ywin=y1(snew(i):end);
    for s=s(i):length(frq_path)
      if frq_path(i)~=0
        fmean=mean([fmean frq_path(i)]);
      end
    end
else
    ywin=y1(snew(i):snew(i+1));
for l=s(i):s(i+1)
    if frq_path(l)~=0
        fmean=mean([fmean frq_path(l)]);
    end
    l=l+1;
   end
end

xnew=pvoc(ywin',f0/fmean);
yout=[yout;xnew];
end
yout=real(yout);
end

